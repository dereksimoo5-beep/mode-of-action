# Modes d'action phyto

Application Streamlit de consultation et de révision des familles chimiques de matières actives phytosanitaires, classées par mode d'action (FRAC / IRAC / HRAC-WSSA).

## Contenu de la base

153 entrées, 142 codes distincts, 477 matières actives citées.

| Catégorie | Entrées | Classification |
|---|---|---|
| Fongicides et bactéricides | 60 | FRAC |
| Insecticides et acaricides | 57 | IRAC |
| Herbicides | 26 | HRAC / WSSA |
| Nématicides | 14 | IRAC, fumigants, biocontrôle |

Colonnes du fichier `data/modes_action.csv` :

`categorie`, `groupe`, `code`, `organisme`, `famille`, `mode_action`, `matieres_actives`, `risque`, `estime`

La colonne `estime` vaut `oui` quand le niveau de risque a été établi par analogie avec une famille voisine, faute de classement officiel publié.

## Installation

```bash
pip install -r requirements.txt
streamlit run app.py
```

L'app s'ouvre sur `http://localhost:8501`.

## Les quatre onglets

**Explorer** — recherche libre insensible aux accents et multi-mots (`complexe III`, `tebuconazole`, `SDHI`, `FRAC 11`). Filtres latéraux par catégorie, classification, niveau de risque. Affichage en fiches ou en tableau, avec export CSV du résultat filtré.

**Révision** — fiches recto-verso. Une matière active tirée au hasard s'affiche, tu retrouves son code et son mode d'action avant de retourner la carte. Les filtres latéraux restreignent le tirage, ce qui permet de réviser une seule catégorie à la fois.

**Quiz** — QCM à cinq types de questions, activables séparément :

1. Code de mode d'action à partir d'une matière active
2. Mode d'action à partir d'un code
3. Famille chimique à partir d'une matière active
4. Niveau de risque de résistance d'un code
5. Deux matières actives partagent-elles le même code (le raisonnement d'alternance)

Les distracteurs sont tirés dans la même catégorie que la bonne réponse, pour que la question reste discriminante. Score, série en cours, meilleure série et récapitulatif des erreurs sont conservés pendant la session.

**Vue d'ensemble** — répartition des entrées par catégorie et par niveau de risque, plus la liste des codes à risque élevé ou très élevé à surveiller en priorité dans un programme.

## Mise à jour de la base

Le fichier `data/modes_action.csv` est éditable directement dans Excel ou LibreOffice. L'app le relit à chaque redémarrage. Pour forcer le rechargement sans redémarrer, utiliser le menu Streamlit puis « Clear cache ».

## Limites

Les listes FRAC, IRAC et HRAC sont révisées chaque année. Vérifier la version en cours avant tout usage réglementaire.

Cette base décrit des familles chimiques, pas des autorisations. Au Maroc, seul l'index phytosanitaire de l'ONSSA fait foi pour l'homologation d'un produit sur une culture et une cible données, ainsi que pour la dose et le délai avant récolte.

Plusieurs matières actives listées sont interdites ou retirées dans la plupart des pays (endosulfan, DDT, carbofuran, bromure de méthyle, paraquat). Elles figurent dans la base pour la complétude de la classification.
